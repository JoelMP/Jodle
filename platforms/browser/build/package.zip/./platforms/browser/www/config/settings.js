
// configuration de la connexion à la base de données
var settings = {
    host: 'ensibd.imag.fr',
    port: 5432,
    database: 'martinpj',
    user: 'martinpj',
    password: 'martinpj'
};

module.exports = {
    settings
};
